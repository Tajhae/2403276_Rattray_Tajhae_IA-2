Coding Conf - CIT2011 IA #2

Student: Tajhae Rattray
Student ID: 2403276

Open HTML/index.html in a browser to view the event page. Extract the complete ZIP before opening the page so the stylesheet and supplied images load from their folders.

Registration flow
1. Select Register now.
2. Enter a name, valid email, @GitHub handle, and JPEG/PNG image smaller than 500 KB.
3. Submit to view the personalized ticket in the browser.

This is a client-side demo and does not send email. Registration details stay in the current browser session.

Desktop and mobile screenshots for the landing page, registration form, and generated ticket are included in screenshots/ and the report. Tablet screenshots are still needed.

Add the GitHub repository and free hosting URLs to the report after publishing.

/* Load the verified registration data and render the personalized pass. */
(function () {
  "use strict";

  let ticketData;
  try {
    ticketData = JSON.parse(sessionStorage.getItem("codingConfTicket"));
  } catch (error) {
    ticketData = null;
  }

  if (!ticketData || !ticketData.fullName || !ticketData.email || !ticketData.github || !ticketData.avatarData) {
    window.location.replace("index.html");
    return;
  }

  const firstName = ticketData.fullName.trim().split(/\s+/)[0];
  document.getElementById("greeting-name").textContent = firstName;
  document.getElementById("ticket-name").textContent = ticketData.fullName;
  document.getElementById("ticket-avatar").src = ticketData.avatarData;
  document.getElementById("ticket-avatar").alt = "Profile photo of " + ticketData.fullName;

  const handle = ticketData.github.replace(/^@/, "");
  const githubLink = document.getElementById("ticket-github");
  githubLink.href = "https://github.com/" + encodeURIComponent(handle);
  githubLink.querySelector("span").textContent = ticketData.github;
}());

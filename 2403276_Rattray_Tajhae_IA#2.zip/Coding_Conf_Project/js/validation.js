/* Validate the registration fields and keep the ticket data in this tab session. */
(function () {
  "use strict";

  const form = document.getElementById("registration-form");
  if (!form) return;

  const fields = {
    fullName: document.getElementById("full-name"),
    email: document.getElementById("email"),
    github: document.getElementById("github"),
    avatar: document.getElementById("avatar")
  };
  const errors = {
    fullName: document.getElementById("name-error"),
    email: document.getElementById("email-error"),
    github: document.getElementById("github-error"),
    avatar: document.getElementById("avatar-error")
  };
  const fileLabel = document.getElementById("file-label");
  const maxAvatarBytes = 500 * 1024;

  function setError(fieldName, message) {
    errors[fieldName].textContent = message;
    fields[fieldName].setAttribute("aria-invalid", message ? "true" : "false");
  }

  function validate() {
    let valid = true;
    const name = fields.fullName.value.trim();
    const email = fields.email.value.trim();
    const github = fields.github.value.trim();
    const file = fields.avatar.files[0];

    const nameError = name ? "" : "Please enter your full name.";
    const emailError = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(email)
      ? "" : "Enter a valid email address, such as name@example.com.";
    const githubError = /^@[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$/.test(github)
      ? "" : "Enter a GitHub handle beginning with @ (letters, numbers or hyphens).";
    let avatarError = "";

    if (!file) avatarError = "Choose a profile photo to continue.";
    else if (!["image/jpeg", "image/png"].includes(file.type)) avatarError = "Use a JPEG or PNG image.";
    else if (file.size >= maxAvatarBytes) avatarError = "Choose an image smaller than 500 KB.";

    setError("fullName", nameError);
    setError("email", emailError);
    setError("github", githubError);
    setError("avatar", avatarError);
    valid = !(nameError || emailError || githubError || avatarError);
    return valid;
  }

  Object.keys(fields).forEach(function (fieldName) {
    const field = fields[fieldName];
    const eventName = fieldName === "avatar" ? "change" : "input";
    field.addEventListener(eventName, function () {
      if (errors[fieldName].textContent) validate();
      if (fieldName === "avatar" && field.files[0]) fileLabel.textContent = field.files[0].name;
    });
  });

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    if (!validate()) {
      const firstInvalid = form.querySelector('[aria-invalid="true"]');
      if (firstInvalid) firstInvalid.focus();
      return;
    }

    const file = fields.avatar.files[0];
    const reader = new FileReader();
    reader.addEventListener("load", function () {
      const ticketData = {
        fullName: fields.fullName.value.trim(),
        email: fields.email.value.trim(),
        github: fields.github.value.trim(),
        avatarData: reader.result
      };
      try {
        sessionStorage.setItem("codingConfTicket", JSON.stringify(ticketData));
        window.location.href = "ticket.html";
      } catch (error) {
        setError("avatar", "This image could not be saved. Choose a smaller photo and try again.");
      }
    });
    reader.addEventListener("error", function () {
      setError("avatar", "We could not read that image. Please choose another file.");
    });
    reader.readAsDataURL(file);
  });
}());
